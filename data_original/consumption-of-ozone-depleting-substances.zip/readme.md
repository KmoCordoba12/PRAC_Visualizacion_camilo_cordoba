# Consumption of ozone-depleting substances - Data package

This data package contains the data that powers the chart ["Consumption of ozone-depleting substances"](https://ourworldindata.org/grapher/consumption-of-ozone-depleting-substances?v=1&csvType=full&useColumnShortNames=false) on the Our World in Data website. It was downloaded on December 02, 2025.

### Active Filters

A filtered subset of the full data was downloaded. The following filters were applied:

## CSV Structure

The high level structure of the CSV file is that each row is an observation for an entity (usually a country or region) and a timepoint (usually a year).

The first two columns in the CSV file are "Entity" and "Code". "Entity" is the name of the entity (e.g. "United States"). "Code" is the OWID internal entity code that we use if the entity is a country or region. For normal countries, this is the same as the [iso alpha-3](https://en.wikipedia.org/wiki/ISO_3166-1_alpha-3) code of the entity (e.g. "USA") - for non-standard countries like historical countries these are custom codes.

The third column is either "Year" or "Day". If the data is annual, this is "Year" and contains only the year as an integer. If the column is "Day", the column contains a date string in the form "YYYY-MM-DD".

The final column is the data column, which is the time series that powers the chart. If the CSV data is downloaded using the "full data" option, then the column corresponds to the time series below. If the CSV data is downloaded using the "only selected data visible in the chart" option then the data column is transformed depending on the chart type and thus the association with the time series might not be as straightforward.

## Metadata.json structure

The .metadata.json file contains metadata about the data package. The "charts" key contains information to recreate the chart, like the title, subtitle etc.. The "columns" key contains information about each of the columns in the csv, like the unit, timespan covered, citation for the data etc..

## About the data

Our World in Data is almost never the original producer of the data - almost all of the data we use has been compiled by others. If you want to re-use data, it is your responsibility to ensure that you adhere to the sources' license and to credit them correctly. Please note that a single time series may have more than one source - e.g. when we stich together data from different time periods by different producers or when we calculate per capita metrics using population data from a second source.

## Detailed information about the data


## Consumption of controlled substance (zero-filled) - Chemical: All (Ozone-depleting)
Consumption of various controlled substances. These include Bromochloromethane (BCM), Carbon Tetrachloride (CTC), Chlorofluorocarbons (CFCs), Hydrobromofluorocarbons (HBFCs), Hydrochlorofluorocarbons (HCFCs), Hydrofluorocarbons (HFCs), Methyl Bromide (MB), Methyl Chloroform (TCA) and Other Fully Halogenated CFCs.

We assign zero to missing values for a given (year, country, chemical) triple. This is due to technical reasons, so that we are able to plot this variable using our Grapher stacked are charts.

Last updated: March 17, 2023  
Date range: 1986–2022  
Unit: ODP tonnes  


### How to cite this data

#### In-line citation
If you have limited space (e.g. in data visualizations), you can use this abbreviated in-line citation:  
UN Environment Programme (2023) – processed by Our World in Data

#### Full citation
UN Environment Programme (2023) – processed by Our World in Data. “Consumption of controlled substance (zero-filled) - Chemical: All (Ozone-depleting)” [dataset]. UN Environment Programme (2023) [original data].
Source: UN Environment Programme (2023) – processed by Our World In Data

### Additional information about this data
Data on the consumption of controlled substances in ODP tonnes or in CO2-eq tonnes

Negative values for a given year imply that quantities destroyed or quantities exported for the year exceeded the sum of production and imports, implying that the destroyed or exported quantities came from stockpiles.


    